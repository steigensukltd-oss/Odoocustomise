
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProjectCard from '@/components/ProjectCard';
import BeforeAfterSection from '@/components/BeforeAfterSection';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { fadeInUp, staggerContainer, staggerItem } from '@/utils/AnimationUtils';

const CaseStudiesPage = () => {
  const projects = [
    {
      title: 'Gulf Trading Co. ERP transformation',
      client: 'Gulf Trading Co.',
      industry: 'Wholesale',
      description: 'Complete migration from legacy system to Odoo 17 with custom inventory management and multi-warehouse support for a UAE-based wholesale distributor.',
      image: 'https://images.unsplash.com/photo-1686545684554-2694c9cee9e6',
      metrics: [
        { value: '87%', label: 'Reduction in stock errors' },
        { value: '3x', label: 'Faster order processing' }
      ]
    },
    {
      title: 'Coastal Retail Group omnichannel solution',
      client: 'Coastal Retail Group',
      industry: 'Retail',
      description: 'Integrated POS system across 12 retail locations with real-time inventory sync and customer loyalty program implementation.',
      image: 'https://images.unsplash.com/photo-1608222351212-18fe0ec7b13b',
      metrics: [
        { value: '42%', label: 'Increase in repeat customers' },
        { value: '2.3x', label: 'Faster checkout times' }
      ]
    },
    {
      title: 'Meridian Manufacturing production optimization',
      client: 'Meridian Manufacturing',
      industry: 'Manufacturing',
      description: 'Custom production planning module with material requirements planning and quality control workflows for a mid-sized manufacturer.',
      image: 'https://images.unsplash.com/photo-1692914274476-0e6920cc80cf',
      metrics: [
        { value: '34%', label: 'Reduction in waste' },
        { value: '28%', label: 'Improved on-time delivery' }
      ]
    },
    {
      title: 'Elm & Oak eCommerce platform',
      client: 'Elm & Oak',
      industry: 'eCommerce',
      description: 'Full-featured online furniture store with custom product configurator, automated shipping integration, and payment gateway setup.',
      image: 'https://images.unsplash.com/photo-1686061593213-98dad7c599b9',
      metrics: [
        { value: '156%', label: 'Growth in online sales' },
        { value: '4.2x', label: 'Faster order fulfillment' }
      ]
    },
    {
      title: 'Apex Healthcare patient management',
      client: 'Apex Healthcare',
      industry: 'Healthcare',
      description: 'HIPAA-compliant patient records system with appointment scheduling, billing integration, and prescription management.',
      image: 'https://images.unsplash.com/photo-1565841327798-694bc2074762',
      metrics: [
        { value: '67%', label: 'Reduction in admin time' },
        { value: '91%', label: 'Patient satisfaction score' }
      ]
    },
    {
      title: 'Global Imports trading platform',
      client: 'Global Imports',
      industry: 'Trading',
      description: 'Multi-currency trading platform with customs documentation automation and international shipping logistics integration.',
      image: 'https://images.unsplash.com/photo-1637739256584-43c96dac387f',
      metrics: [
        { value: '52%', label: 'Faster customs clearance' },
        { value: '3.8x', label: 'More shipments handled' }
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Case Studies | Successful Odoo Implementations</title>
        <meta name="description" content="Real-world Odoo ERP success stories from UAE and India. See how we've transformed businesses across wholesale, retail, manufacturing, healthcare, and eCommerce sectors." />
        <meta name="keywords" content="Odoo case studies, Odoo success stories, Odoo implementation examples, ERP transformation results" />
        <meta property="og:title" content="Case Studies | Successful Odoo Implementations" />
        <meta property="og:description" content="Discover how businesses have transformed their operations with our Odoo solutions." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Real results from real businesses
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Explore how we've helped companies across different industries transform their operations with custom Odoo solutions.
              </p>
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {projects.map((project, index) => (
                <ProjectCard key={index} {...project} index={index} />
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Before & after transformations</h2>
              <p className="text-lg max-w-3xl mx-auto leading-relaxed mb-12">
                See the tangible impact of our Odoo implementations on business operations and efficiency.
              </p>
            </motion.div>
            <BeforeAfterSection />
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to write your success story?</h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Join the growing list of businesses that have transformed their operations with our Odoo expertise.
              </p>
              <a href="/contact">
                <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 active:scale-[0.98]">
                  Start your transformation
                </button>
              </a>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default CaseStudiesPage;
