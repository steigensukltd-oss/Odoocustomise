
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import BlogCard from '@/components/BlogCard';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { Badge } from '@/components/ui/badge';
import { fadeInUp, staggerContainer, staggerItem } from '@/utils/AnimationUtils';

const BlogPage = () => {
  const categories = ['All', 'Odoo Tips', 'ERP Best Practices', 'Case Studies', 'Industry Insights', 'Technical Guides'];

  const blogPosts = [
    {
      title: '10 ways Odoo can transform your wholesale business',
      excerpt: 'Discover how implementing Odoo ERP can streamline inventory management, automate order processing, and provide real-time insights for wholesale distributors.',
      category: 'Industry Insights',
      date: 'May 2, 2026',
      image: 'https://images.unsplash.com/photo-1608222351212-18fe0ec7b13b'
    },
    {
      title: 'Migrating from legacy ERP to Odoo: A complete guide',
      excerpt: 'Step-by-step guide to planning and executing a successful migration from outdated ERP systems to Odoo without disrupting your business operations.',
      category: 'Technical Guides',
      date: 'April 28, 2026',
      image: 'https://images.unsplash.com/photo-1686061593213-98dad7c599b9'
    },
    {
      title: 'How we reduced ERP costs by 73% for a UAE trading company',
      excerpt: 'Real case study showing how strategic Odoo implementation helped a Dubai-based trading company cut software costs while improving functionality.',
      category: 'Case Studies',
      date: 'April 24, 2026',
      image: 'https://images.unsplash.com/photo-1692914274476-0e6920cc80cf'
    },
    {
      title: 'Essential Odoo modules for retail businesses',
      excerpt: 'Comprehensive overview of must-have Odoo modules for retail operations, from POS integration to customer loyalty programs.',
      category: 'Odoo Tips',
      date: 'April 19, 2026',
      image: 'https://images.unsplash.com/photo-1565841327798-694bc2074762'
    },
    {
      title: 'Automating invoice generation in Odoo',
      excerpt: 'Learn how to set up automated invoicing workflows in Odoo to save time and reduce manual errors in your billing process.',
      category: 'Technical Guides',
      date: 'April 15, 2026',
      image: 'https://images.unsplash.com/photo-1637739256584-43c96dac387f'
    },
    {
      title: 'Why UAE businesses are switching to Odoo',
      excerpt: 'Analysis of the growing trend of UAE companies adopting Odoo ERP and the specific benefits driving this shift in the regional market.',
      category: 'Industry Insights',
      date: 'April 10, 2026',
      image: 'https://images.unsplash.com/photo-1686545684554-2694c9cee9e6'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Odoo Development Blog | Tips, Guides & Industry Insights</title>
        <meta name="description" content="Expert insights on Odoo ERP development, implementation best practices, case studies, and industry trends. Learn from our experience serving UAE and India markets." />
        <meta name="keywords" content="Odoo blog, Odoo tips, ERP best practices, Odoo tutorials, Odoo case studies" />
        <meta property="og:title" content="Odoo Development Blog | Tips, Guides & Industry Insights" />
        <meta property="og:description" content="Expert insights and practical guides for Odoo ERP implementation and optimization." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Insights & resources
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Expert tips, case studies, and practical guides to help you get the most out of your Odoo ERP system.
              </p>
            </motion.div>

            <motion.div className="flex flex-wrap gap-3 justify-center mb-12" {...fadeInUp}>
              {categories.map((category, index) => (
                <Badge
                  key={index}
                  variant={index === 0 ? 'default' : 'secondary'}
                  className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  {category}
                </Badge>
              ))}
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {blogPosts.map((post, index) => (
                <BlogCard key={index} {...post} index={index} />
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Stay updated</h2>
              <p className="text-lg mb-8 leading-relaxed">
                Subscribe to our newsletter for the latest Odoo tips, industry insights, and exclusive content delivered to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 active:scale-[0.98] whitespace-nowrap">
                  Subscribe
                </button>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default BlogPage;
