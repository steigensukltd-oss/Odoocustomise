
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Gift, Package, ShoppingBag, Factory, Heart, TrendingUp, Store } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import IndustryCard from '@/components/IndustryCard';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { fadeInUp, staggerContainer, staggerItem } from '@/utils/AnimationUtils';

const IndustriesPage = () => {
  const industries = [
    {
      icon: Gift,
      title: 'Corporate gifting',
      description: 'Streamline bulk order management, client databases, and personalized gift tracking with custom Odoo solutions designed for corporate gifting businesses.'
    },
    {
      icon: Package,
      title: 'Wholesale',
      description: 'Manage large inventory volumes, supplier relationships, and multi-location warehouses with powerful wholesale-focused ERP features.'
    },
    {
      icon: ShoppingBag,
      title: 'Retail',
      description: 'Integrate point-of-sale systems, inventory management, and customer loyalty programs for seamless retail operations across multiple locations.'
    },
    {
      icon: Factory,
      title: 'Manufacturing',
      description: 'Optimize production planning, material requirements, quality control, and supply chain management with industry-specific manufacturing modules.'
    },
    {
      icon: Heart,
      title: 'Healthcare',
      description: 'Manage patient records, appointment scheduling, billing, and compliance requirements with HIPAA-compliant healthcare ERP solutions.'
    },
    {
      icon: TrendingUp,
      title: 'Trading companies',
      description: 'Handle import/export documentation, multi-currency transactions, and international shipping logistics with specialized trading modules.'
    },
    {
      icon: Store,
      title: 'eCommerce',
      description: 'Build powerful online stores with integrated inventory, payment processing, shipping automation, and customer management systems.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Industries We Serve | Odoo Solutions for Every Sector</title>
        <meta name="description" content="Specialized Odoo ERP solutions for corporate gifting, wholesale, retail, manufacturing, healthcare, trading, and eCommerce industries. Industry-specific customizations for UAE and India." />
        <meta name="keywords" content="Odoo for retail, Odoo manufacturing ERP, Odoo healthcare solutions, Odoo eCommerce platform, Odoo wholesale management" />
        <meta property="og:title" content="Industries We Serve | Odoo Solutions for Every Sector" />
        <meta property="og:description" content="Industry-specific Odoo ERP solutions tailored to your business needs." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Industry-specific Odoo solutions
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                We understand that each industry has unique challenges. Our Odoo solutions are tailored to meet the specific needs of your sector.
              </p>
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {industries.map((industry, index) => (
                <IndustryCard key={index} {...industry} index={index} />
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-12" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Why industry expertise matters</h2>
              <p className="text-lg max-w-3xl mx-auto leading-relaxed mb-12">
                Generic ERP solutions often fall short because they don't account for industry-specific workflows. Our team brings deep domain knowledge to every project.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div {...fadeInUp}>
                <img
                  src="https://images.unsplash.com/photo-1637739256584-43c96dac387f"
                  alt="UAE business district showcasing modern commerce"
                  className="rounded-2xl shadow-lg"
                />
              </motion.div>
              <motion.div {...fadeInUp} className="space-y-6">
                <div>
                  <h3 className="font-semibold text-xl mb-3">Compliance & regulations</h3>
                  <p className="leading-relaxed">
                    We ensure your Odoo system meets industry-specific compliance requirements, from healthcare regulations to financial reporting standards.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-xl mb-3">Best practices built-in</h3>
                  <p className="leading-relaxed">
                    Our solutions incorporate industry best practices, saving you time and reducing the learning curve for your team.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-xl mb-3">Scalable architecture</h3>
                  <p className="leading-relaxed">
                    As your business grows, our industry-focused solutions scale seamlessly to accommodate increased complexity and volume.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Don't see your industry?</h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                We work with businesses across diverse sectors. Contact us to discuss how we can customize Odoo for your specific industry needs.
              </p>
              <a href="/contact">
                <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 active:scale-[0.98]">
                  Discuss your requirements
                </button>
              </a>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default IndustriesPage;
