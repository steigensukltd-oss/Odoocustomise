
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Users, Globe, Award } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { fadeInUp } from '@/utils/AnimationUtils';

const AboutPage = () => {
  const values = [
    {
      icon: Target,
      title: 'Mission-driven',
      description: 'We exist to make premium Odoo development accessible to businesses of all sizes, eliminating cost barriers without compromising quality.'
    },
    {
      icon: Users,
      title: 'Client-focused',
      description: 'Your success is our success. We build long-term partnerships based on trust, transparency, and exceptional results.'
    },
    {
      icon: Globe,
      title: 'Global perspective',
      description: 'Operating from Kerala with clients in UAE and beyond, we bring international standards to every project.'
    },
    {
      icon: Award,
      title: 'Quality commitment',
      description: 'We never compromise on code quality, security, or best practices, regardless of project size or budget.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>About Us | Expert Odoo Development Team</title>
        <meta name="description" content="Learn about our Odoo development team with real business experience. Based in Kerala, India, serving UAE and international clients with affordable, high-quality ERP solutions." />
        <meta name="keywords" content="Odoo development team, Odoo experts Kerala, Odoo developers India, About Odoo agency" />
        <meta property="og:title" content="About Us | Expert Odoo Development Team" />
        <meta property="og:description" content="Built by a team with real business experience. Discover our story and commitment to excellence." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Built by a team with real business experience
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                We're not just developers — we're business owners who understand the challenges you face because we've lived them.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
              <motion.div {...fadeInUp}>
                <img
                  src="https://images.unsplash.com/photo-1565841327798-694bc2074762"
                  alt="Development team collaborating on Odoo projects"
                  className="rounded-2xl shadow-lg"
                />
              </motion.div>
              <motion.div {...fadeInUp} className="space-y-6">
                <h2 className="text-3xl font-bold">Our story</h2>
                <p className="leading-relaxed text-muted-foreground">
                  Founded by entrepreneurs who managed multiple brands and complex business workflows, we intimately understand the pain points of disconnected systems, manual processes, and expensive software solutions.
                </p>
                <p className="leading-relaxed text-muted-foreground">
                  After successfully implementing Odoo for our own businesses and experiencing the transformative impact firsthand, we decided to make this powerful platform accessible to other companies at a fraction of the typical cost.
                </p>
                <p className="leading-relaxed text-muted-foreground">
                  Today, we're proud to serve clients across UAE and India, bringing enterprise-grade ERP solutions to businesses that previously couldn't afford them.
                </p>
              </motion.div>
            </div>

            <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" {...fadeInUp}>
              {values.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{value.description}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-12" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Why we're different</h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <motion.div {...fadeInUp}>
                <h3 className="font-semibold text-xl mb-4">Real business experience</h3>
                <p className="leading-relaxed mb-6">
                  Unlike traditional development agencies, our team has hands-on experience running businesses. We've dealt with inventory management, customer relationships, financial reporting, and all the operational challenges you face daily.
                </p>
                <p className="leading-relaxed">
                  This practical knowledge informs every solution we build, ensuring we create systems that actually work in the real world, not just in theory.
                </p>
              </motion.div>

              <motion.div {...fadeInUp}>
                <h3 className="font-semibold text-xl mb-4">Affordable excellence</h3>
                <p className="leading-relaxed mb-6">
                  By operating from Kerala, India with a lean, efficient team, we eliminate the overhead costs that make traditional agencies expensive. We pass these savings directly to you without cutting corners on quality.
                </p>
                <p className="leading-relaxed">
                  Our developers are highly skilled professionals who follow international coding standards and best practices on every project.
                </p>
              </motion.div>

              <motion.div {...fadeInUp}>
                <h3 className="font-semibold text-xl mb-4">Long-term partnership approach</h3>
                <p className="leading-relaxed mb-6">
                  We're not interested in one-off projects. We want to be your technology partner as your business grows and evolves.
                </p>
                <p className="leading-relaxed">
                  That's why we include comprehensive training, detailed documentation, and ongoing support with every implementation.
                </p>
              </motion.div>

              <motion.div {...fadeInUp}>
                <h3 className="font-semibold text-xl mb-4">Global vision, local expertise</h3>
                <p className="leading-relaxed mb-6">
                  With clients in UAE and India, we understand both international business standards and local market nuances.
                </p>
                <p className="leading-relaxed">
                  We're expanding our reach globally while maintaining the personalized service and attention to detail that defines our work.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Let's build something great together</h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Whether you're a startup looking to establish efficient processes or an established company ready to modernize your systems, we're here to help.
              </p>
              <a href="/contact">
                <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 active:scale-[0.98]">
                  Get in touch
                </button>
              </a>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default AboutPage;
