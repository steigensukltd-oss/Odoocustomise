
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Globe, Settings, Plug, ShoppingCart, ArrowUpCircle, Wrench, Zap, Package } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ServiceCard from '@/components/ServiceCard';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { fadeInUp, staggerContainer, staggerItem } from '@/utils/AnimationUtils';

const ServicesPage = () => {
  const services = [
    {
      icon: Globe,
      title: 'Odoo website development',
      description: 'Custom Odoo websites with responsive design, SEO optimization, and seamless CMS integration.',
      features: [
        'Mobile-first responsive design',
        'SEO-optimized structure',
        'Custom theme development',
        'Multi-language support'
      ]
    },
    {
      icon: Settings,
      title: 'Odoo ERP customization',
      description: 'Tailored ERP solutions that match your unique business processes and workflows.',
      features: [
        'Custom workflow automation',
        'Business-specific modifications',
        'User role customization',
        'Report customization'
      ]
    },
    {
      icon: Plug,
      title: 'Odoo API integration',
      description: 'Connect Odoo with third-party applications for a unified business ecosystem.',
      features: [
        'Payment gateway integration',
        'Shipping provider APIs',
        'CRM system connections',
        'Accounting software sync'
      ]
    },
    {
      icon: ShoppingCart,
      title: 'Odoo eCommerce development',
      description: 'Full-featured online stores with inventory management and payment processing.',
      features: [
        'Product catalog management',
        'Shopping cart optimization',
        'Payment gateway setup',
        'Order tracking system'
      ]
    },
    {
      icon: ArrowUpCircle,
      title: 'Odoo migration & upgrade',
      description: 'Seamless migration from legacy systems or older Odoo versions to the latest platform.',
      features: [
        'Data migration planning',
        'Zero-downtime upgrades',
        'Version compatibility checks',
        'Post-migration testing'
      ]
    },
    {
      icon: Wrench,
      title: 'Odoo support & maintenance',
      description: 'Ongoing technical support, bug fixes, and system optimization services.',
      features: [
        '24/7 technical support',
        'Regular system updates',
        'Performance optimization',
        'Security patches'
      ]
    },
    {
      icon: Zap,
      title: 'Odoo automation',
      description: 'Automate repetitive tasks and streamline business processes with smart workflows.',
      features: [
        'Workflow automation',
        'Email automation',
        'Report generation',
        'Task scheduling'
      ]
    },
    {
      icon: Package,
      title: 'Custom module development',
      description: 'Build specialized modules tailored to your industry-specific requirements.',
      features: [
        'Industry-specific features',
        'Custom business logic',
        'Third-party integrations',
        'Scalable architecture'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Odoo Development Services | ERP Customization & Integration</title>
        <meta name="description" content="Comprehensive Odoo development services including ERP customization, API integration, eCommerce development, migration, and ongoing support. Expert solutions for UAE and India." />
        <meta name="keywords" content="Odoo ERP customization UAE, Odoo API integration, Odoo eCommerce development, Odoo migration services, Odoo support company UAE" />
        <meta property="og:title" content="Odoo Development Services | ERP Customization & Integration" />
        <meta property="og:description" content="Expert Odoo development services for businesses in UAE and India. Custom ERP solutions at affordable rates." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Comprehensive Odoo development services
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                From custom development to ongoing support, we provide end-to-end Odoo solutions that drive business growth and operational efficiency.
              </p>
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {services.map((service, index) => (
                <ServiceCard key={index} {...service} index={index} />
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Need a custom solution?</h2>
              <p className="text-lg mb-8 leading-relaxed">
                Every business is unique. Let's discuss how we can tailor our Odoo services to meet your specific requirements.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <a href="/contact" className="inline-block">
                  <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-all duration-200 active:scale-[0.98]">
                    Schedule a consultation
                  </button>
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default ServicesPage;
