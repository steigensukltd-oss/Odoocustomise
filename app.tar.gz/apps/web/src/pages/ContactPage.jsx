
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, MessageCircle } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ConsultationBooking from '@/components/ConsultationBooking';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { fadeInUp } from '@/utils/AnimationUtils';
import { Loader2 } from 'lucide-react';

const WHATSAPP_URL = 'https://api.whatsapp.com/send/?phone=917012223507&text=Hey%2C+I+just+wanted+to+know+more+details+about+Odoo+development.+Could+you+please+share+the+information%3F&type=phone_number&app_absent=0';

const ContactPage = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: '',
    message: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Message sent",
        description: "We'll get back to you within 24 hours."
      });
      setFormData({ name: '', email: '', phone: '', company: '', service: '', message: '' });
    }, 1500);
  };

  return (
    <>
      <Helmet>
        <title>Contact Us | Get Free Odoo Consultation</title>
        <meta name="description" content="Contact our Odoo development team for a free consultation. Dubai: +971 55 711 2553, India: +91 7012223507. Email: contact@odooexperts.com" />
        <meta name="keywords" content="Contact Odoo developer, Odoo consultation UAE, Odoo support India, Odoo development inquiry" />
        <meta property="og:title" content="Contact Us | Get Free Odoo Consultation" />
        <meta property="og:description" content="Reach out for expert Odoo development services. Free consultation available." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Let's discuss your project
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Get in touch with our team for a free consultation. We're here to answer your questions and help you find the right Odoo solution.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <motion.div className="lg:col-span-2" {...fadeInUp}>
                <div className="bg-card border border-border rounded-2xl p-8 shadow-sm">
                  <h2 className="text-2xl font-bold mb-6">Send us a message</h2>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          required
                          className="text-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          required
                          className="text-foreground"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="text-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="company">Company</Label>
                        <Input
                          id="company"
                          value={formData.company}
                          onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                          className="text-foreground"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="service">Service interest</Label>
                      <Select value={formData.service} onValueChange={(value) => setFormData({ ...formData, service: value })}>
                        <SelectTrigger className="text-foreground">
                          <SelectValue placeholder="Select a service" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="website">Odoo website development</SelectItem>
                          <SelectItem value="customization">ERP customization</SelectItem>
                          <SelectItem value="integration">API integration</SelectItem>
                          <SelectItem value="ecommerce">eCommerce development</SelectItem>
                          <SelectItem value="migration">Migration & upgrade</SelectItem>
                          <SelectItem value="support">Support & maintenance</SelectItem>
                          <SelectItem value="automation">Automation</SelectItem>
                          <SelectItem value="custom">Custom module development</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        rows={6}
                        required
                        className="text-foreground"
                      />
                    </div>

                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                      Send message
                    </Button>
                  </form>
                </div>
              </motion.div>

              <motion.div className="space-y-6" {...fadeInUp}>
                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                  <h3 className="font-semibold text-lg mb-6">Contact information</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Phone className="w-5 h-5 text-primary" />
                      </div>
                      <div className="space-y-2 pt-1">
                        <div>
                          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Call Dubai, UAE</div>
                          <a href="tel:+971557112553" className="text-sm font-semibold hover:text-primary transition-colors">+971 55 711 2553</a>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-[#25D366]/10 flex items-center justify-center shrink-0">
                        <MessageCircle className="w-5 h-5 text-[#25D366]" />
                      </div>
                      <div className="space-y-2 pt-1">
                        <div>
                          <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">WhatsApp India</div>
                          <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="text-sm font-semibold hover:text-[#25D366] transition-colors">+91 7012223507</a>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div className="pt-1">
                        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Email us</div>
                        <a href="mailto:contact@odooexperts.com" className="text-sm font-semibold hover:text-primary transition-colors">contact@odooexperts.com</a>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <MapPin className="w-5 h-5 text-primary" />
                      </div>
                      <div className="pt-1">
                        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Location</div>
                        <div className="text-sm font-medium">Kerala, India <br/> Dubai, UAE</div>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Clock className="w-5 h-5 text-primary" />
                      </div>
                      <div className="pt-1">
                        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Business hours</div>
                        <div className="text-sm font-medium">Mon-Fri: 9:00 AM - 6:00 PM IST</div>
                      </div>
                    </div>
                  </div>
                </div>

                <ConsultationBooking />
              </motion.div>
            </div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default ContactPage;
