
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle2, Users, Clock, Globe, Shield, Zap, Headphones as HeadphonesIcon } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CTAButton from '@/components/CTAButton';
import TestimonialCard from '@/components/TestimonialCard';
import AnimatedCounter from '@/components/AnimatedCounter';
import FAQ from '@/components/FAQ';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import QuickInquiryForm from '@/components/QuickInquiryForm';
import SchemaMarkup from '@/utils/SchemaMarkup';
import { fadeInUp, staggerContainer, staggerItem } from '@/utils/AnimationUtils';

const HomePage = () => {
  const [inquiryOpen, setInquiryOpen] = useState(false);

  const whyChooseUs = [
    {
      icon: Zap,
      title: '75% lower cost',
      description: 'Premium Odoo development at a fraction of market rates without compromising quality'
    },
    {
      icon: Clock,
      title: 'Quick delivery',
      description: 'Streamlined processes ensure faster project completion and rapid deployment'
    },
    {
      icon: Users,
      title: 'Dedicated developers',
      description: 'Experienced team members assigned exclusively to your project'
    },
    {
      icon: Globe,
      title: 'UAE market experience',
      description: 'Deep understanding of regional business requirements and compliance'
    },
    {
      icon: Shield,
      title: 'Transparent communication',
      description: 'Regular updates, clear timelines, and honest project management'
    },
    {
      icon: CheckCircle2,
      title: 'Scalable solutions',
      description: 'Future-proof architecture that grows with your business needs'
    },
    {
      icon: HeadphonesIcon,
      title: 'Long-term support',
      description: 'Comprehensive maintenance and ongoing technical assistance'
    }
  ];

  const testimonials = [
    {
      name: 'Ahmed Al-Rashid',
      company: 'Gulf Trading Co.',
      role: 'Operations Director',
      quote: 'The team delivered our custom Odoo ERP solution ahead of schedule and under budget. Their understanding of UAE business processes was exceptional.',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      rating: 5
    },
    {
      name: 'Priya Menon',
      company: 'Coastal Retail Group',
      role: 'CEO',
      quote: 'We migrated from an outdated system to Odoo 17 seamlessly. The cost savings compared to other quotes were remarkable, and the quality exceeded expectations.',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      rating: 5
    },
    {
      name: 'Rajesh Kumar',
      company: 'Meridian Manufacturing',
      role: 'IT Manager',
      quote: 'Their custom module development transformed our production workflow. The team was responsive, professional, and delivered exactly what we needed.',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      rating: 5
    }
  ];

  return (
    <>
      <Helmet>
        <title>Expert Odoo Development at 1/4th Market Price | UAE & India</title>
        <meta name="description" content="Professional Odoo ERP development, customization, and support services. Serving UAE and India with affordable, high-quality solutions. Get free consultation today." />
        <meta name="keywords" content="Odoo developer UAE, Odoo freelancer India, Affordable Odoo development, Odoo ERP customization UAE, Odoo website developer Kerala" />
        <meta property="og:title" content="Expert Odoo Development at 1/4th Market Price" />
        <meta property="og:description" content="Professional Odoo ERP development serving UAE and India. Premium quality at affordable rates." />
        <meta property="og:type" content="website" />
      </Helmet>
      <SchemaMarkup />
      
      <div className="min-h-screen bg-background">
        <Header />
        
        <section className="relative min-h-[90vh] flex items-center overflow-hidden noise-texture">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div {...fadeInUp}>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6" style={{letterSpacing: '-0.02em'}}>
                  Expert Odoo development at <span className="text-gradient">1/4th the market price</span>
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-prose">
                  Transform your business with custom Odoo ERP solutions. Serving UAE and India with premium development, seamless integrations, and dedicated support.
                </p>
                <div className="flex flex-wrap gap-4">
                  <CTAButton variant="consultation" onClick={() => setInquiryOpen(true)} />
                  <CTAButton variant="quote" onClick={() => setInquiryOpen(true)} />
                  <CTAButton variant="whatsapp" />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="relative"
              >
                <div className="grid grid-cols-2 gap-4">
                  <img
                    src="https://images.unsplash.com/photo-1608222351212-18fe0ec7b13b"
                    alt="Odoo dashboard interface showing analytics and reports"
                    className="rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 animate-float"
                  />
                  <img
                    src="https://images.unsplash.com/photo-1686061593213-98dad7c599b9"
                    alt="Modern ERP system with data visualization"
                    className="rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 mt-8 animate-float"
                    style={{ animationDelay: '1s' }}
                  />
                  <img
                    src="https://images.unsplash.com/photo-1692914274476-0e6920cc80cf"
                    alt="Business workflow automation diagram"
                    className="rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 -mt-8 animate-float"
                    style={{ animationDelay: '2s' }}
                  />
                  <img
                    src="https://images.unsplash.com/photo-1565841327798-694bc2074762"
                    alt="Development team collaborating remotely"
                    className="rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 animate-float"
                    style={{ animationDelay: '3s' }}
                  />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section id="why-choose-us" className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Why choose us</h2>
              <p className="text-lg max-w-2xl mx-auto leading-relaxed">
                Built by a team with real business experience, we understand your challenges and deliver solutions that work.
              </p>
            </motion.div>

            <motion.div
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {whyChooseUs.map((item, index) => (
                <motion.div
                  key={index}
                  variants={staggerItem}
                  className="flex gap-4"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <item.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                    <p className="text-sm leading-relaxed">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Trusted by businesses worldwide</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Join the growing number of companies that have transformed their operations with our Odoo solutions.
              </p>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                  <AnimatedCounter end={47} suffix="+" />
                </div>
                <div className="text-sm text-muted-foreground">Projects completed</div>
              </div>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                  <AnimatedCounter end={23} suffix="+" />
                </div>
                <div className="text-sm text-muted-foreground">Happy clients</div>
              </div>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                  <AnimatedCounter end={6} suffix="+" />
                </div>
                <div className="text-sm text-muted-foreground">Years of experience</div>
              </div>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                  <AnimatedCounter end={18} /> <span className="text-2xl">days</span>
                </div>
                <div className="text-sm text-muted-foreground">Average delivery time</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((testimonial, index) => (
                <TestimonialCard key={index} {...testimonial} index={index} />
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted text-muted-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center mb-16" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Frequently asked questions</h2>
              <p className="text-lg max-w-2xl mx-auto leading-relaxed">
                Find answers to common questions about our Odoo development services.
              </p>
            </motion.div>
            <FAQ />
          </div>
        </section>

        <section className="py-20 bg-primary text-primary-foreground">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to transform your business?</h2>
              <p className="text-lg mb-8 leading-relaxed opacity-90">
                Get a free consultation and discover how our Odoo solutions can streamline your operations.
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <CTAButton variant="consultation" onClick={() => setInquiryOpen(true)} className="bg-white text-primary hover:bg-white/90" />
                <CTAButton variant="whatsapp" />
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
        <QuickInquiryForm open={inquiryOpen} onOpenChange={setInquiryOpen} />
      </div>
    </>
  );
};

export default HomePage;
