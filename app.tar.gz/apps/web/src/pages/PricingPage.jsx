
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CTAButton from '@/components/CTAButton';
import StickyWhatsAppButton from '@/components/StickyWhatsAppButton';
import { Badge } from '@/components/ui/badge';
import { fadeInUp } from '@/utils/AnimationUtils';

const PricingPage = () => {
  return (
    <>
      <Helmet>
        <title>Odoo Development Pricing | Custom ERP Solutions</title>
        <meta name="description" content="Flexible and transparent pricing for Odoo development services. Custom packages starting from $49 USD, tailored to your specific business needs." />
        <meta name="keywords" content="Odoo development pricing, Affordable Odoo development, Odoo ERP cost UAE, Odoo customization pricing" />
        <meta property="og:title" content="Odoo Development Pricing | Custom ERP Solutions" />
        <meta property="og:description" content="Flexible pricing plans for Odoo development. Premium quality tailored to your specific needs." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />

        <section className="py-20 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div className="text-center mb-12" {...fadeInUp}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{letterSpacing: '-0.02em'}}>
                Flexible, value-driven pricing
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                We believe in delivering maximum value without rigid constraints. Our pricing adapts to your unique business requirements.
              </p>
            </motion.div>

            <motion.div 
              className="max-w-4xl mx-auto bg-card border border-border rounded-3xl p-8 md:p-12 shadow-xl text-center relative overflow-hidden mb-12"
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary via-primary/50 to-primary" />
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
              
              <div className="relative z-10">
                <Badge className="mb-6 bg-primary/10 text-primary hover:bg-primary/20 border-none px-4 py-1.5 text-sm">
                  Tailored Solutions
                </Badge>
                <h2 className="text-4xl md:text-5xl font-extrabold mb-4 text-foreground">Custom Package</h2>
                
                <div className="flex items-baseline justify-center gap-2 mb-6">
                  <span className="text-muted-foreground text-lg font-medium">Pricing starts from</span>
                  <span className="text-5xl md:text-6xl font-black text-primary">$49</span>
                  <span className="text-xl text-muted-foreground font-medium">USD</span>
                </div>
                
                <p className="text-lg text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
                  Every business is unique, and so are its requirements. Our custom packages are meticulously tailored to your specific project needs, emphasizing flexibility, scalability, and personalized solutions that drive real operational value.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <CTAButton variant="consultation" size="lg" className="w-full sm:w-auto text-base px-8 h-14" />
                  <CTAButton variant="quote" size="lg" className="w-full sm:w-auto text-base px-8 h-14" />
                </div>
              </div>
            </motion.div>

            <motion.div className="text-center bg-muted rounded-2xl p-8 max-w-4xl mx-auto" {...fadeInUp}>
              <h3 className="text-2xl font-bold mb-4">Custom pricing available for UAE and international projects</h3>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto leading-relaxed">
                We understand that every region has different market dynamics. Contact us for a personalized quote tailored to your specific geographic requirements, timeline, and budget.
              </p>
              <div className="flex justify-center">
                <CTAButton variant="whatsapp" />
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div className="text-center" {...fadeInUp}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Why our pricing is different</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mt-12">
                <div className="bg-background/50 p-6 rounded-2xl border border-border/50">
                  <h3 className="font-semibold text-lg mb-3">No hidden fees</h3>
                  <p className="text-sm leading-relaxed text-secondary-foreground/80">
                    What you see is what you pay. All costs are transparent and discussed upfront before any work begins.
                  </p>
                </div>
                <div className="bg-background/50 p-6 rounded-2xl border border-border/50">
                  <h3 className="font-semibold text-lg mb-3">Flexible payment terms</h3>
                  <p className="text-sm leading-relaxed text-secondary-foreground/80">
                    Milestone-based payments ensure you only pay as tangible progress is made on your project.
                  </p>
                </div>
                <div className="bg-background/50 p-6 rounded-2xl border border-border/50">
                  <h3 className="font-semibold text-lg mb-3">Value-driven approach</h3>
                  <p className="text-sm leading-relaxed text-secondary-foreground/80">
                    We focus on delivering maximum operational value and ROI, not just completing tasks on a checklist.
                  </p>
                </div>
                <div className="bg-background/50 p-6 rounded-2xl border border-border/50">
                  <h3 className="font-semibold text-lg mb-3">Long-term partnership</h3>
                  <p className="text-sm leading-relaxed text-secondary-foreground/80">
                    Our pricing reflects our commitment to supporting your business growth well beyond the initial project completion.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        <Footer />
        <StickyWhatsAppButton />
      </div>
    </>
  );
};

export default PricingPage;
