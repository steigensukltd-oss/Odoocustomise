
import React from 'react';
import { motion } from 'framer-motion';

const ClientLogoSlider = ({ logos = [] }) => {
  const duplicatedLogos = [...logos, ...logos];

  return (
    <div className="overflow-hidden py-8">
      <motion.div
        className="flex gap-12"
        animate={{
          x: [0, -50 * logos.length + '%']
        }}
        transition={{
          x: {
            repeat: Infinity,
            repeatType: "loop",
            duration: 20,
            ease: "linear"
          }
        }}
      >
        {duplicatedLogos.map((logo, index) => (
          <div
            key={index}
            className="flex-shrink-0 w-32 h-16 flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100"
          >
            <img src={logo.src} alt={logo.alt} className="max-w-full max-h-full object-contain" />
          </div>
        ))}
      </motion.div>
    </div>
  );
};

export default ClientLogoSlider;
