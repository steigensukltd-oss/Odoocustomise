
import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const FAQ = () => {
  const faqs = [
    {
      question: "What makes your Odoo development services more affordable?",
      answer: "We operate from Kerala, India with a highly skilled team, allowing us to offer premium Odoo development at 1/4th the market price without compromising quality. Our streamlined processes and efficient project management keep costs low while delivering exceptional results."
    },
    {
      question: "How long does a typical Odoo implementation take?",
      answer: "Project timelines vary based on complexity. A basic Odoo website takes 2-3 weeks, while full ERP customization can take 6-12 weeks. We provide detailed timelines during the consultation phase and maintain transparent communication throughout."
    },
    {
      question: "Do you provide support after project completion?",
      answer: "Yes, we offer comprehensive post-launch support including bug fixes, updates, and maintenance packages. Our support team is available via email, phone, and WhatsApp to ensure your Odoo system runs smoothly."
    },
    {
      question: "Can you work with clients in UAE and other international markets?",
      answer: "Absolutely. We have extensive experience serving UAE-based clients and understand the regional business requirements. We offer flexible communication channels and work hours to accommodate different time zones."
    },
    {
      question: "What Odoo versions do you work with?",
      answer: "We work with all Odoo versions from 13 to the latest release. We also specialize in migration services to help you upgrade from older versions to the latest Odoo platform."
    },
    {
      question: "Do you offer custom module development?",
      answer: "Yes, custom module development is one of our core services. We build tailored modules to match your specific business processes, ensuring seamless integration with your existing Odoo setup."
    },
    {
      question: "What industries do you specialize in?",
      answer: "We have expertise across multiple industries including corporate gifting, wholesale, retail, manufacturing, healthcare, trading companies, and eCommerce. Our team adapts Odoo solutions to fit industry-specific workflows."
    },
    {
      question: "How do you ensure data security during migration?",
      answer: "We follow strict security protocols including encrypted data transfers, secure backup systems, and compliance with international data protection standards. All client data is handled with complete confidentiality."
    },
    {
      question: "Can you integrate Odoo with third-party applications?",
      answer: "Yes, we specialize in API integrations connecting Odoo with payment gateways, shipping providers, accounting software, CRM systems, and other business tools to create a unified ecosystem."
    },
    {
      question: "What is your payment structure?",
      answer: "We offer flexible payment terms with milestone-based billing. Typically, we require 30% upfront, 40% at mid-project, and 30% upon completion. Custom payment plans are available for larger projects."
    },
    {
      question: "Do you provide training for our team?",
      answer: "Yes, we include comprehensive training as part of our implementation package. We conduct hands-on sessions to ensure your team can effectively use and manage the Odoo system."
    },
    {
      question: "What if we need changes after the project is completed?",
      answer: "We offer ongoing support packages and are always available for additional customizations. Minor adjustments within the first month are typically included in the project scope."
    }
  ];

  return (
    <div className="max-w-3xl mx-auto">
      <Accordion type="single" collapsible className="space-y-4">
        {faqs.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`} className="border border-border rounded-xl px-6 bg-card">
            <AccordionTrigger className="text-left font-semibold hover:no-underline">
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground leading-relaxed">
              {faq.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
};

export default FAQ;
