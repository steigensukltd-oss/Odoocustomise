
import React from 'react';
import { motion } from 'framer-motion';

const ClientLogoSection = () => {
  const clients = [
    { name: 'Client A', color: 'bg-blue-500' },
    { name: 'Client B', color: 'bg-green-500' },
    { name: 'Client C', color: 'bg-purple-500' },
    { name: 'Client D', color: 'bg-orange-500' },
    { name: 'Client E', color: 'bg-pink-500' },
    { name: 'Client F', color: 'bg-teal-500' }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
      {clients.map((client, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: index * 0.1 }}
          className="flex items-center justify-center"
        >
          <div className={`w-24 h-24 rounded-xl ${client.color} opacity-20 hover:opacity-40 transition-opacity duration-300 flex items-center justify-center`}>
            <span className="text-white font-bold text-xs">{client.name}</span>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default ClientLogoSection;
