
import React from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle, Calendar, FileText } from 'lucide-react';

const WHATSAPP_URL = 'https://api.whatsapp.com/send/?phone=917012223507&text=Hey%2C+I+just+wanted+to+know+more+details+about+Odoo+development.+Could+you+please+share+the+information%3F&type=phone_number&app_absent=0';

const CTAButton = ({ variant = 'consultation', size = 'default', className = '', onClick }) => {
  const variants = {
    consultation: {
      icon: Calendar,
      text: 'Get free consultation',
      className: 'bg-primary text-primary-foreground hover:bg-primary/90'
    },
    quote: {
      icon: FileText,
      text: 'Request quote',
      className: 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
    },
    whatsapp: {
      icon: MessageCircle,
      text: 'WhatsApp us',
      className: 'bg-[#25D366] text-white hover:bg-[#20BD5A]'
    }
  };

  const config = variants[variant];
  const Icon = config.icon;

  const handleClick = (e) => {
    if (onClick) {
      onClick(e);
      return;
    }
    
    if (variant === 'whatsapp') {
      window.open(WHATSAPP_URL, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Button
      size={size}
      className={`${config.className} ${className} transition-all duration-200 active:scale-[0.98]`}
      onClick={handleClick}
    >
      <Icon className="w-4 h-4 mr-2" />
      {config.text}
    </Button>
  );
};

export default CTAButton;
