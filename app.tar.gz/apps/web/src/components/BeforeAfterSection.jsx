
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const BeforeAfterSection = () => {
  const transformations = [
    {
      before: "Manual inventory tracking with spreadsheets",
      after: "Real-time automated inventory management with alerts",
      metric: "87% reduction in stock errors"
    },
    {
      before: "Disconnected sales and accounting systems",
      after: "Unified ERP with automated invoicing and reporting",
      metric: "3x faster month-end closing"
    },
    {
      before: "Limited customer data visibility",
      after: "360° customer view with purchase history and analytics",
      metric: "42% increase in repeat orders"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {transformations.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <Card className="h-full border-border hover:shadow-lg transition-shadow duration-300">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="bg-destructive/10 rounded-lg p-4">
                  <div className="text-xs font-medium text-destructive mb-2 uppercase tracking-wide">Before</div>
                  <p className="text-sm">{item.before}</p>
                </div>
                <div className="flex justify-center">
                  <ArrowRight className="w-5 h-5 text-primary" />
                </div>
                <div className="bg-primary/10 rounded-lg p-4">
                  <div className="text-xs font-medium text-primary mb-2 uppercase tracking-wide">After</div>
                  <p className="text-sm">{item.after}</p>
                </div>
                <div className="pt-2 border-t border-border">
                  <div className="text-lg font-bold text-primary">{item.metric}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default BeforeAfterSection;
