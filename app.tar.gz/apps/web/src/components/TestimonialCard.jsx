
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Star } from 'lucide-react';
import { motion } from 'framer-motion';

const TestimonialCard = ({ name, company, role, quote, image, rating = 5, index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="h-full border-border hover:shadow-lg transition-shadow duration-300">
        <CardContent className="pt-6">
          <div className="flex gap-1 mb-4">
            {[...Array(rating)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-primary text-primary" />
            ))}
          </div>
          <blockquote className="text-sm leading-relaxed mb-6 italic">
            "{quote}"
          </blockquote>
          <div className="flex items-center gap-3">
            <Avatar className="rounded-xl">
              <AvatarImage src={image} alt={name} />
              <AvatarFallback className="rounded-xl bg-primary/10 text-primary">
                {name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="font-semibold text-sm">{name}</div>
              <div className="text-xs text-muted-foreground">{role} at {company}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TestimonialCard;
