
import React from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';

const StickyWhatsAppButton = () => {
  const whatsappUrl = 'https://api.whatsapp.com/send/?phone=917012223507&text=Hey%2C+I+just+wanted+to+know+more+details+about+Odoo+development.+Could+you+please+share+the+information%3F&type=phone_number&app_absent=0';

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Button
        asChild
        className="w-14 h-14 rounded-full bg-[#25D366] text-white hover:bg-[#20BD5A] shadow-lg hover:shadow-xl transition-all duration-200 active:scale-95"
        size="icon"
        aria-label="Contact us on WhatsApp"
      >
        <a 
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          <MessageCircle className="w-6 h-6" />
        </a>
      </Button>
    </div>
  );
};

export default StickyWhatsAppButton;
