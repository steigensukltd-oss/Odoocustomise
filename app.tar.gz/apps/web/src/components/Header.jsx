
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, X, Phone } from 'lucide-react';
import CTAButton from './CTAButton';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Pricing', path: '/pricing' },
    { name: 'Industries', path: '/industries' },
    { name: 'Case studies', path: '/case-studies' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' }
  ];

  const isActive = (path) => {
    if (path.includes('#')) {
      return location.pathname === '/' && location.hash === path.split('#')[1];
    }
    return location.pathname === path;
  };

  return (
    <header className={`sticky top-0 z-40 w-full transition-all duration-300 ${
      isScrolled ? 'bg-background/95 backdrop-blur-md shadow-sm border-b border-border' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">O</span>
            </div>
            <span className="font-bold text-lg hidden sm:block">Odoo Experts</span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                  isActive(link.path)
                    ? 'text-primary bg-primary/10'
                    : 'text-foreground hover:text-primary hover:bg-accent'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <div className="hidden xl:flex flex-col items-end border-r border-border pr-4 mr-1">
              <a href="tel:+971557112553" className="text-xs font-medium hover:text-primary flex items-center gap-1 transition-colors">
                <span className="text-muted-foreground text-[10px]">UAE:</span> +971 55 711 2553
              </a>
              <a href="tel:+917012223507" className="text-xs font-medium hover:text-primary flex items-center gap-1 transition-colors mt-0.5">
                <span className="text-muted-foreground text-[10px]">IN:</span> +91 7012223507
              </a>
            </div>
            <CTAButton variant="consultation" size="sm" />
          </div>

          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px] overflow-y-auto">
              <nav className="flex flex-col gap-2 mt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                      isActive(link.path)
                        ? 'text-primary bg-primary/10'
                        : 'text-foreground hover:bg-accent'
                    }`}
                  >
                    {link.name}
                  </Link>
                ))}
                
                <div className="mt-6 px-4 py-4 bg-muted rounded-xl space-y-3 border border-border">
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Call us directly</div>
                  <a href="tel:+971557112553" className="flex items-center gap-3 text-sm font-medium hover:text-primary transition-colors">
                    <div className="w-8 h-8 rounded-full bg-background flex items-center justify-center shrink-0 border border-border">
                      <Phone className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground font-normal">Dubai, UAE</div>
                      <div>+971 55 711 2553</div>
                    </div>
                  </a>
                  <a href="tel:+917012223507" className="flex items-center gap-3 text-sm font-medium hover:text-primary transition-colors">
                    <div className="w-8 h-8 rounded-full bg-background flex items-center justify-center shrink-0 border border-border">
                      <Phone className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground font-normal">Kerala, India</div>
                      <div>+91 7012223507</div>
                    </div>
                  </a>
                </div>

                <div className="flex flex-col gap-3 mt-6 px-4 pb-8">
                  <CTAButton variant="consultation" className="w-full" onClick={() => setMobileMenuOpen(false)} />
                  <CTAButton variant="quote" className="w-full" onClick={() => setMobileMenuOpen(false)} />
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
