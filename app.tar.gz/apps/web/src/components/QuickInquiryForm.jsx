
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const WHATSAPP_URL = 'https://api.whatsapp.com/send/?phone=917012223507&text=Hey%2C+I+just+wanted+to+know+more+details+about+Odoo+development.+Could+you+please+share+the+information%3F&type=phone_number&app_absent=0';

const QuickInquiryForm = ({ open, onOpenChange }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    service: '',
    callbackRegion: '',
    message: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Inquiry submitted",
        description: "We'll get back to you within 24 hours.",
        action: (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => window.open(WHATSAPP_URL, '_blank', 'noopener,noreferrer')}
            className="border-[#25D366] text-[#25D366] hover:bg-[#25D366] hover:text-white"
          >
            WhatsApp Us Now
          </Button>
        ),
      });
      onOpenChange(false);
      setFormData({ name: '', email: '', service: '', callbackRegion: '', message: '' });
    }, 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Quick inquiry</DialogTitle>
          <DialogDescription>
            Fill out the form below and our team will get back to you shortly.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="text-foreground"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="text-foreground"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="callback">Preferred callback region</Label>
              <Select value={formData.callbackRegion} onValueChange={(value) => setFormData({ ...formData, callbackRegion: value })}>
                <SelectTrigger className="text-foreground">
                  <SelectValue placeholder="Select region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uae">Dubai (+971 55 711 2553)</SelectItem>
                  <SelectItem value="india">India (WhatsApp)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="service">Service interest</Label>
            <Select value={formData.service} onValueChange={(value) => setFormData({ ...formData, service: value })}>
              <SelectTrigger className="text-foreground">
                <SelectValue placeholder="Select a service" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="website">Odoo website development</SelectItem>
                <SelectItem value="customization">ERP customization</SelectItem>
                <SelectItem value="integration">API integration</SelectItem>
                <SelectItem value="ecommerce">eCommerce development</SelectItem>
                <SelectItem value="migration">Migration & upgrade</SelectItem>
                <SelectItem value="support">Support & maintenance</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              rows={4}
              className="text-foreground"
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Submit inquiry
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default QuickInquiryForm;
