
import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Linkedin, Twitter, Facebook } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary text-secondary-foreground border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">O</span>
              </div>
              <span className="font-bold text-lg">Odoo Experts</span>
            </div>
            <p className="text-sm leading-relaxed mb-4 text-secondary-foreground/80">
              Expert Odoo development at 1/4th the market price. Serving businesses in UAE and India with premium ERP solutions.
            </p>
            <div className="flex gap-2">
              <Badge variant="outline" className="border-secondary-foreground/20">Kerala, India</Badge>
              <Badge variant="outline" className="border-secondary-foreground/20">Dubai, UAE</Badge>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Quick links</h3>
            <ul className="space-y-2">
              <li><Link to="/services" className="text-sm hover:text-primary transition-colors">Services</Link></li>
              <li><Link to="/pricing" className="text-sm hover:text-primary transition-colors">Pricing</Link></li>
              <li><Link to="/industries" className="text-sm hover:text-primary transition-colors">Industries</Link></li>
              <li><Link to="/case-studies" className="text-sm hover:text-primary transition-colors">Case studies</Link></li>
              <li><Link to="/about" className="text-sm hover:text-primary transition-colors">About us</Link></li>
              <li><Link to="/blog" className="text-sm hover:text-primary transition-colors">Blog</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm">
                <Phone className="w-4 h-4 mt-1 flex-shrink-0 text-primary" />
                <div className="space-y-1">
                  <div>
                    <span className="text-xs text-secondary-foreground/70 block">Dubai, UAE</span>
                    <a href="tel:+971557112553" className="hover:text-primary transition-colors font-medium">+971 55 711 2553</a>
                  </div>
                  <div>
                    <span className="text-xs text-secondary-foreground/70 block pt-1">Kerala, India</span>
                    <a href="tel:+917012223507" className="hover:text-primary transition-colors font-medium">+91 7012223507</a>
                  </div>
                </div>
              </li>
              <li className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 flex-shrink-0 text-primary" />
                <a href="mailto:contact@odooexperts.com" className="hover:text-primary transition-colors">contact@odooexperts.com</a>
              </li>
              <li className="flex items-start gap-3 text-sm">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-primary" />
                <span>Kerala, India <br/> Dubai, UAE</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Follow us</h3>
            <div className="flex gap-3 mb-6">
              <a href="#" aria-label="LinkedIn" className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#" aria-label="Twitter" className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" aria-label="Facebook" className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link to="/privacy" className="text-sm hover:text-primary transition-colors">Privacy policy</Link></li>
              <li><Link to="/terms" className="text-sm hover:text-primary transition-colors">Terms of service</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-secondary-foreground/70">
          <p>&copy; {currentYear} Odoo Experts. All rights reserved.</p>
          <p>Elevating businesses with affordable ERP solutions.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
