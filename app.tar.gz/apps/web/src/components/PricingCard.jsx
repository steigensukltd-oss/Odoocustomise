
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check } from 'lucide-react';
import { motion } from 'framer-motion';

const PricingCard = ({ title, description, price, period, features = [], recommended = false, index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className={recommended ? 'scale-105' : ''}
    >
      <Card className={`h-full flex flex-col ${recommended ? 'ring-2 ring-primary shadow-xl' : 'border-border'}`}>
        <CardHeader>
          {recommended && (
            <Badge className="w-fit mb-2 bg-primary text-primary-foreground">Recommended</Badge>
          )}
          <CardTitle className="text-2xl font-bold">{title}</CardTitle>
          <CardDescription className="text-muted-foreground">{description}</CardDescription>
          <div className="mt-4">
            <span className="text-4xl font-bold">{price}</span>
            {period && <span className="text-muted-foreground ml-2">/{period}</span>}
          </div>
        </CardHeader>
        <CardContent className="flex-1">
          <ul className="space-y-3">
            {features.map((feature, idx) => (
              <li key={idx} className="flex items-start">
                <Check className="w-5 h-5 text-primary mr-3 flex-shrink-0 mt-0.5" />
                <span className="text-sm">{feature}</span>
              </li>
            ))}
          </ul>
        </CardContent>
        <CardFooter className="mt-auto">
          <Button 
            className={`w-full ${recommended ? 'bg-primary text-primary-foreground hover:bg-primary/90' : ''}`}
            variant={recommended ? 'default' : 'outline'}
          >
            Get started
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default PricingCard;
