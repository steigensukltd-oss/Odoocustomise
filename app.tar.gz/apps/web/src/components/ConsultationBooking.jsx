
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Phone, MessageCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

const WHATSAPP_URL = 'https://api.whatsapp.com/send/?phone=917012223507&text=Hey%2C+I+just+wanted+to+know+more+details+about+Odoo+development.+Could+you+please+share+the+information%3F&type=phone_number&app_absent=0';

const ConsultationBooking = () => {
  const [date, setDate] = useState();
  const [time, setTime] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ];

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Consultation booked",
        description: "You'll receive a confirmation email shortly."
      });
      setDate(undefined);
      setTime('');
      setName('');
      setEmail('');
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <Card className="border-border">
        <CardHeader>
          <CardTitle>Book a free consultation</CardTitle>
          <CardDescription>
            Choose a date and time that works for you
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label>Select date</Label>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                disabled={(date) => date < new Date() || date.getDay() === 0 || date.getDay() === 6}
                className="rounded-xl border border-border"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="time">Select time</Label>
              <Select value={time} onValueChange={setTime}>
                <SelectTrigger id="time" className="text-foreground">
                  <SelectValue placeholder="Choose a time slot" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((slot) => (
                    <SelectItem key={slot} value={slot}>{slot}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="booking-name">Name</Label>
              <Input
                id="booking-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="text-foreground"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="booking-email">Email</Label>
              <Input
                id="booking-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="text-foreground"
              />
            </div>
            <Button type="submit" className="w-full" disabled={!date || !time || loading}>
              {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Book consultation
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="border-border bg-muted/50">
        <CardContent className="p-6">
          <h3 className="font-semibold text-sm mb-4">Prefer to contact us directly?</h3>
          <div className="space-y-3">
            <a href="tel:+971557112553" className="flex items-center gap-3 p-3 rounded-lg bg-background border border-border hover:border-primary/50 transition-colors group">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Call Dubai, UAE</div>
                <div className="text-sm font-medium group-hover:text-primary transition-colors">+971 55 711 2553</div>
              </div>
            </a>
            <a 
              href={WHATSAPP_URL} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-lg bg-background border border-border hover:border-[#25D366]/50 transition-colors group"
            >
              <div className="w-8 h-8 rounded-full bg-[#25D366]/10 flex items-center justify-center group-hover:bg-[#25D366] group-hover:text-white transition-colors">
                <MessageCircle className="w-4 h-4 text-[#25D366] group-hover:text-white" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">WhatsApp India</div>
                <div className="text-sm font-medium group-hover:text-[#25D366] transition-colors">+91 7012223507</div>
              </div>
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ConsultationBooking;
